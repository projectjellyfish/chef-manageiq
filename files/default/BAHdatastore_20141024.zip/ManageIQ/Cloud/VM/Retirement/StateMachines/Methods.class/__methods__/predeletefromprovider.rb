#
# Description: This retirement method runs prior to deleting the VM from VC
#
# Retirement customizations for predelete from provider would go here.
