#
# Description: This method launches the host provisioning job
#

$evm.root["miq_host_provision"].execute
