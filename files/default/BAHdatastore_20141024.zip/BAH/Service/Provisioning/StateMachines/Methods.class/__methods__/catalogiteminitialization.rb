#
# Description: Tag service and set provison options based on service dialog entries.
# 1. Look for all Service Dialog Options in the service_template_provision_task.dialog_options
#    (i.e. Dialog options that came from either a Catalog Bundle Service or a Service Dialog)
# 2. The dialog_tags variable will be used to tag the desination Catalog Item Service and any
#    subordinate miq_provision tasks. The dialog_tags should be a string with the format of
#    "[{"tagcat1":"tagval1"},{"tagcat2":"tagval2"}]" so it can be parsed into a JSON array of hashes.
# 3. The remaining Service Dialog Option keys are simply passed into the subordinate
#    miq_provision object. I.e. option_0_vm_memory => 2048
#
# Inputs: $evm.root['service_template_provision_task'].dialog_options
#
require 'json'

# Look for service dialog variables in the dialog options hash that start with "option_[0-9]",
def get_options_hash(dialog_options)
  # Setup regular expression for service dialog tags
  options_regex = /^dialog_option_\d*_(.*)/
  options_hash = {}

  # Loop through all of the options and build an options_hash from them
  dialog_options.each do |k, v|
    if options_regex =~ k
      option_key = Regexp.last_match[1].to_sym
      option_value = v

      unless option_value.blank?
        $evm.log("info", "Adding option_key:<#{option_key.inspect}> option_value:<#{option_value.inspect}> to options_hash")
        options_hash[option_key] = option_value
      end
    else
      unless v.nil?
        $evm.log("info", "Adding option:<#{k.to_sym.inspect}> value:<#{v.inspect}> to options_hash")
        options_hash[k.to_sym] = v
      end
    end
  end
  $evm.log("info", "Inspecting options_hash:<#{options_hash.inspect}>")
  options_hash
end

# Look in tags_hash for tags and tag the service
def tag_service(service, tags_array)
  # split the dialog string into an array of hashes
  # it should come in with a format like: %Q|[{"tagcat1":"tagval1"},{"tagcat2":"tagval2"}]|

  
  # Look for tags with a sequence_id of 0 to tag the destination Service
  unless tags_array.nil?  
    tags_array.each do |t|
      k = t.keys[0]
      v = t.values[0]
      $evm.log("info", "Adding Tag:<#{k}/#{v}> to Service:<#{service.name}>")
      service.tag_assign("#{k}/#{v}")
    end
  end
end

# Get the task object from root
service_template_provision_task = $evm.root['service_template_provision_task']

# Get destination service object
service = service_template_provision_task.destination
service.name = $evm.root['dialog_servicename']

$evm.log("info", "Detected Service:<#{service.name}> Id:<#{service.id}>")



# Get dialog options from options hash
# {:dialog=>{"option_0_myvar"=>"myprefix", "option_1_vservice_workers"=>"2", "tag_0_environment"=>"test", "tag_0_location"=>"paris",
# "option_2_vm_memory"=>"2048", "option_0_vlan"=>"Internal", "option_1_cores_per_socket"=>"1"}}
dialog_options = service_template_provision_task.dialog_options
$evm.log("info", "Inspecting Dialog Options:<#{dialog_options.inspect}>")

# Tag Service
tags_array = []
unless $evm.root['dialog_tags'].nil?
  #$evm.log("info", "Dialog Tags is a: <#{$evm.root['dialog_tags'].class}>")
  #$evm.log("info", "Inspecting Dialog Tags: <#{$evm.root['dialog_tags'].inspect}>")
  begin
    # swap out the spaceships with colons. Not sure why this is necessary but it is.
    dialog_tags = $evm.root['dialog_tags'].gsub("=>",":")
    tags_array = JSON.parse(dialog_tags)

    tag_service(service, tags_array)
  rescue
    $evm.log("info", "Tagging skipped for service: <#{service.name}>")
  end
end

# Get options_hash
options_hash = get_options_hash(dialog_options)

# Process Child Tasks
service_template_provision_task.miq_request_tasks.each do |t|

  # Process grandchildren service options
  unless t.miq_request_tasks.nil?
    grandchild_tasks = t.miq_request_tasks
    grandchild_tasks.each do |gc|
      $evm.log("info", "Detected Grandchild Task ID:<#{gc.id}> Description:<#{gc.description}> source type:<#{gc.source_type}>")

      # If child task is provisioning then apply tags and options
      if gc.source_type == "template"
        unless tags_array.nil?
           tags_array.each do |t|
              k = t.keys[0]
              v = t.values[0]
              $evm.log("info", "Adding Tag:<#{k.inspect}/#{v.inspect}> to Provisioning ID:<#{gc.id}>")
              gc.add_tag(k, v)
            end
        end
        unless options_hash.nil?
          options_hash.each do |k, v|
            $evm.log("info", "Adding Option:<{#{k.inspect} => #{v.inspect}}> to Provisioning ID:<#{gc.id}>")
            gc.set_option(k, v)
          end
        end
      else
        $evm.log("info", "Invalid Source Type:<#{gc.source_type}>. Skipping task ID:<#{gc.id}>")
      end # if gc.source_type
    end # grandchild_tasks.each do
  end # unless t.miq_request_tasks.nil?
end # service_template_provision_task.miq_request_tasks.each do
