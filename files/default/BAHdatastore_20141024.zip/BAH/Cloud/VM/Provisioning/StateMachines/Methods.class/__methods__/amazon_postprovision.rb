#
# Description: This method is used to process tasks immediately after the VM has been provisioned and send a message back to servicemix
#

require 'json'
require 'aws-sdk'
require 'rest-client'
require 'erb'

# =================================
# miq connector module 
# =================================
module MiqConnector

  class ServicemixPayload
    attr_accessor :data, :template

    def initialize(data)
      @template = %{
        {
          "status": "#{data[:status]}",
          "description": "#{data[:description]}",
          "order_id":"#{data[:order_id]}",
          "items": [
            <% data[:items].each_with_index do |item, index| %>
            {
              "order_product_id":"#{data[:order_product_id]}",
              "mpuuid": "<%= item[:mpuuid] %>",
              "public_fqdn": "<%=item[:fqdn] %>",
              "cloudforms_guid": "<%= item[:cloudforms_guid] %>",
              "public_ip_addr": "<%= item[:public_ip_address] %>",
              "aws_instance_id": "<%= item[:aws_instance_id] %>",
              "private_fqdn": "<%= item[:private_fqdn] %>",
              "private_ip_addr": "<%= item[:private_ip_address] %>",
              "status": "<%= item[:status] %>",
              "vmid": "<%= item[:vmid] %>"
            }<% if index+1 != data[:items].length %>,<% end %>
            <% end %>
          ]
        }
      }
      @data = data
    end

    def json()
      b = binding
      template = ERB.new(@template, 0, "%<>")
      return template.result(b)
    end

  end

  class MiqConnector
    attr_accessor :aws_instance_data, :miq_request_data

    def log(msg)
      #@logger_file.puts(msg)
      $evm.log("info", msg)
    end

    def initialize(miq_request_data)
      @miq_request_data = miq_request_data
      #@logger_file = File.open('/home/miqbuilder/miq_connector.log', 'a')
      
      raise "Unexpected/Incomplete configuration" if !self.is_configured?
    
      # push the uid_ems into an array
      aws_vm_ids = [@miq_request_data[:miq_vm].uid_ems]
      log("Loading AWS data ....")
      @aws_instance_data = load_amazon_instance_collection_info(aws_vm_ids)
      log("AWS data loaded")
      log("== AWS data ===============")
      log(@aws_instance_data.inspect)
      log("== END AWS data ===============")
    end

    def process_order
      # json template for servicemix
      data = {}
      data[:status] = "completed"
      data[:description] = "Order Provisioned Successfully"
      data[:order_product_id] = @miq_request_data[:order_product_id]
      data[:order_id] = @miq_request_data[:order_id]
      items = [] # this should only be one item

      if @aws_instance_data.data.has_key?(:instances_set)
        puts "has 'instances_set'"
        instances = @aws_instance_data.data[:instances_set]
      else
        instances = @aws_instance_data.data[:instance_index]
      end

      # this should only be a single instance
      instances.each do |aws_i|
        aws_instance = aws_i[1]
        # find the aws vm object that matches the current aws instance
        #miq_vm = @miq_request_data[:aws_vms].find{|e| e.uid_ems == aws_instance[:instance_id]}
        miq_vm = @miq_request_data[:miq_vm]

        # build the item array of hashes for servicemix
        item = {
          :order_product_id => @miq_request_data[:order_product_id],
          :mpuuid => @miq_request_data[:mpuuid],
          :public_fqdn => aws_instance[:dns_name],
          :cloudforms_guid => miq_vm.guid,
          :public_ip_address => aws_instance[:ip_address],
          :aws_instance_id => aws_instance[:instance_id],
          :private_fqdn => aws_instance[:private_dns_name],
          :private_ip_address => aws_instance[:private_ip_address],
          :ip_addr => aws_instance[:ip_address],
          :vmid => miq_vm.id,
          :status => "completed"
          
        }

        # add the item to items array for this order
        items.push item
      end


      data[:items] = items
      
      # inject the data into the template
      servicemix_payload = ServicemixPayload.new(data)
      servicemix_data = servicemix_payload.json()

      # send the data off to servicemix with all of the instance data
      log(servicemix_data.to_json)
      update_servicemix(servicemix_data)
    end

    def is_configured?
      if (is_servicemix_configured? && is_amazon_configured?)
        return true
      else
        return false
      end
    end

    def is_servicemix_configured?
      if !@miq_request_data[:servicemix_url].nil?
        return true
      else
        return false
      end
    end

    # this should probably be more generic for any cloud provider configuration
    def is_amazon_configured?
      if !@miq_request_data[:aws_access_key_id].nil? && !@miq_request_data[:aws_secret_access_key].nil?
        return true
      else
        return false
      end
    end

    def load_amazon_instance_collection_info(instance_ids)
      ec2_client = AWS::EC2::Client.new(
          :access_key_id => @miq_request_data[:aws_access_key_id],
          :secret_access_key => @miq_request_data[:aws_secret_access_key]
        )
      log("== EC2 Client created")
      return ec2_client.describe_instances(:instance_ids => instance_ids)
    end


    def update_servicemix(json_to_post)
      begin
        resp = RestClient.post(@miq_request_data[:servicemix_url], json_to_post, :content_type => :json){|response, request, result, &block|
          log("== Data sent to servicemix ============================")
          log(json_to_post)
          log("== End Data sent to servicemix ============================")
          case response.code

          when 200
            log("servicemix returned code 200 and updated successfully")
          else
            log("servicemix returned code #{response.code}")
          end

        }
      rescue => e
        log("== Problem sending data to servicemix")
      end
    end

  end
end

# =================================
# end miq connector module
# =================================

begin

  @method = 'amazon_postprovision'
  @debug = true

  $evm.log("info", "#{@method}")

  $evm.log("info", "== Begin root attributes")
  $evm.root.attributes.sort.each {|k,v| $evm.log("info", "#{k}: #{v}") }
  $evm.log("info", "== END root attributes")

  $evm.log("info", "== Begin miq_provision inspect")
  $evm.log("info", $evm.root['miq_provision'].inspect_all)
  $evm.log("info", "== END miq_provision inspect")

  # Get Variables
  prov = $evm.root["miq_provision"]
  $evm.log("info", "Provisioning ID:<#{prov.id}> Provision Request ID:<#{prov.miq_provision_request.id}> Provision Type: <#{prov.provision_type}>")

  # Get provisioned VM from prov object
  vm = prov.vm

  unless vm.nil?
    $evm.log("info", "VM:<#{vm.name}> has been provisioned. Called in the cloud/vm statemachine")
    $evm.log("info", "===== vm inspect all")
    $evm.log("info", vm.inspect_all)
    $evm.log("info", "vm.uid_ems: #{vm.uid_ems}")
    $evm.log("info", "vm.ipaddresses: #{vm.ipaddresses}")
    $evm.log("info", "vm.hostnames: #{vm.hostnames}")
    $evm.log("info", "vm.type: #{vm.type}")
    $evm.log("info", "vm.vendor: #{vm.vendor}")
    $evm.log("info", "===== end vm inspect all")
  else
    $evm.log("info", "VM object was nil")
  end

  $evm.log("info", "==== Begin miq_provision dialog options")
  $evm.log("info", "prov.get_option(:dialog_servicemix_url): #{prov.get_option(:dialog_servicemix_url)}")
  $evm.log("info", "prov.get_option(:dialog_order_id): #{prov.get_option(:dialog_order_id)}")

  $evm.log("info", "==== END miq_provision dialog options")

  # build the data that the miq connector class need to be instantiated
  miq_request_data = {
    :servicemix_url => prov.get_option(:dialog_servicemix_url),
    :order_id => prov.get_option(:dialog_order_id),
    :order_product_id => prov.get_option(:dialog_order_product_id),
    :aws_access_key_id => 'TODO set this', 
    :aws_secret_access_key => 'TODO set this',
    :miq_vm => vm,
    :mpuuid => prov.get_option(:dialog_mpuuid)
  }

  $evm.log("info", "Task Status==#{prov.status}")
  dpi = MiqConnector::MiqConnector.new(miq_request_data)
  $evm.log("info", "dpi object instantiated successfully")

  if prov.status != 'ok'
    $evm.log("warn", "Provision Failed for order: #{prov.get_option(:dialog_order_id)}, order_product_id:#{prov.get_option(:dialog_order_product_id)}")
    failed_msg = %{
      {
        "status": "failed",
        "description": "The order has failed",
        "order_id":"#{prov.get_option(:dialog_order_id)}",
        "items": [{
            "order_product_id": "#{miq_request_data[:order_product_id]}",
            "mpuuid": "none",
            "public_fqdn": "none",
            "cloudforms_guid": "none",
            "public_ip_addr": "none",
            "aws_instance_id": "none",
            "private_fqdn": "",
            "private_ip_addr": "",
            "status": "failed",
            "vmid": "none"
          }]
      }
    }
    dpi.update_servicemix(failed_msg)
  else
    dpi.process_order()
  end
  $evm.log("info", "servicemix updated successfully.")

exit MIQ_OK

rescue => err
  $evm.log("error", "#{@method} - [#{err}]\n#{err.backtrace.join("\n")}")
  exit MIQ_STOP
end




